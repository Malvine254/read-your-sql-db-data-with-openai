import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, MetaData
from langchain_openai import AzureChatOpenAI
from langchain.prompts.chat import ChatPromptTemplate
from langchain_community.agent_toolkits.sql.base import create_sql_agent
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain.agents import AgentType
from flask import Flask, render_template, request
import html

# Load environment variables from .env file
load_dotenv()

# Retrieve environment variables
OPENAI_API_TYPE = 'azure'
OPENAI_API_VERSION = '2024-02-01'
OPENAI_API_BASE = 'https://armelyopenai.openai.azure.com/'
OPENAI_API_KEY = 'bf960d750ff946e8a8908e7f5ed53b71'
OPENAI_CHAT_MODEL = 'gpt-4-model'

SQL_SERVER = 'readtablewithopenai.database.windows.net'
SQL_DB = 'sql_db'
SQL_USERNAME = 'sql_db'
SQL_PWD = 'Igneus1998$'

# Create the SQLAlchemy engine
driver = '{ODBC Driver 17 for SQL Server}'
odbc_str = (
    'mssql+pyodbc:///?odbc_connect='
    f'Driver={driver};Server=tcp:{SQL_SERVER};PORT=1433;DATABASE={SQL_DB};'
    f'Uid={SQL_USERNAME};Pwd={SQL_PWD};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'
)

db_engine = create_engine(odbc_str)

# Reflect the tables in the database and filter out system tables
metadata = MetaData()
metadata.reflect(bind=db_engine)
user_tables = [
    table_name for table_name in metadata.tables
    if not table_name.lower().startswith("sys")
]

# Initialize AzureChatOpenAI
llm = AzureChatOpenAI(
    api_key=OPENAI_API_KEY,
    azure_endpoint=OPENAI_API_BASE,
    api_version=OPENAI_API_VERSION,
    model=OPENAI_CHAT_MODEL,
    deployment_name=OPENAI_CHAT_MODEL,
    temperature=0
)

# Initialize SQL Database and Toolkit
db = SQLDatabase(db_engine)
sql_toolkit = SQLDatabaseToolkit(db=db, llm=llm)

# Define the conversation prompt
final_prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful AI assistant expert in querying SQL Database to find answers to user's questions about Patients, Orders, and Products."),
    ("user", "{question}\n ai: "),
])

# Create SQL DB Agent
sqldb_agent = create_sql_agent(
    llm=llm,
    toolkit=sql_toolkit,
    agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

def convert_llm_response_to_html(llm_response):
    # Initialize HTML output list
    html_parts = []

    # Define styles for the AI role
    styles = {
        "ai": 'color: red; font-weight: bold;'
    }

    # Process the 'output' section
    if 'output' in llm_response:
        content = llm_response['output']
        # Escape special HTML characters and replace newlines with <br> tags
        escaped_content = html.escape(content).replace("\n", "<br>")

        # Append formatted HTML block for the response section
        html_parts.append(
            f'<div style="{styles.get("ai", "")}">AI:</div><div style="margin-left: 20px;">{escaped_content}</div>')

    # Join all parts into a single HTML string and return
    return ''.join(html_parts)

# Flask application setup
app = Flask(__name__)

def checkIfNull(value):
    return value if value else "Give examples of records I can search"

@app.route("/", methods=["GET", "POST"])
def index():
    query = ""
    response = ""
    if request.method == "POST":
        query = checkIfNull(request.form.get("query"))
        response = convert_llm_response_to_html(sqldb_agent.invoke(final_prompt.format(question=query)))
    return render_template("index.html", response=response, query=query)

if __name__ == "__main__":
    app.run(debug=True)
